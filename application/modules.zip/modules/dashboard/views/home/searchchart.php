<canvas id="lineChart2" height="100"></canvas>
<input name="monthnamesr" id="monthnamesr" type="hidden" value="<?php echo $monthname;?>" />
<input name="monthlysaleamountsr" id="monthlysaleamountsr" type="hidden" value="<?php echo $monthlysaleamount;?>" />
<input name="monthlysaleordersr" id="monthlysaleordersr" type="hidden" value="<?php echo $monthlysaleorder;?>" />
<script src="<?php echo base_url('assets/js/Chart.min.js') ?>" type="text/javascript"></script>
<script src="<?php echo base_url('dashboard/home/chartjs') ?>" type="text/javascript"></script> 
<script src="<?php echo base_url('application/modules/dashboard/assest/js/chartdatasearch.js'); ?>" type="text/javascript"></script>
 

